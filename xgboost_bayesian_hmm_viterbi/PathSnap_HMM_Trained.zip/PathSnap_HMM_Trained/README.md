# PathSnap trained HMM/Viterbi results

Held-out top-1 accuracy: **87.8392%** (16,830 / 19,160 observations).
Requested 85–95% range met: **True**.

| Model | Student-test Top-1 | Route Continuity | Mean Trip Accuracy |
| --- | --- | --- | --- |
| XGBoost (18 features) | 0.830063 | 0.948303 | 0.844357 |
| XGBoost (18 features) + HMM/Viterbi | 0.878392 | 0.999373 | 0.898219 |

Top-1 for the HMM is the single Viterbi-selected arc agreeing with the supplied reference arc at an observation. Every test observation is included, including missing-candidate observations. These are geometric weak reference labels, so this score measures reference agreement rather than independently verified road truth.

The model uses 18 GPS/network features for XGBoost emissions and a directed-network transition model. Viterbi finds the most likely candidate sequence under those scores. Transition parameters were tuned with 80 seeded Optuna trials using out-of-fold emissions from all 80 training trips and the original five trip folds. The emission parameters were retained from the notebook's baseline to prioritize speed. No XGBoost Bayesian search was run. This is a discriminative hybrid, not a standalone Baum-Welch-trained generative HMM.

The decoder and final emission settings were frozen before a single evaluation on the original 10 student-test trips. Training OOF decoder scores are selection scores, not unbiased nested-CV estimates. The test score was not used to change model settings. The compiled decoder was checked against the original recurrence on three training trips, including reset events.

## Included

- `PathSnap_shared18.zip`: full reusable 18-feature train/test dataset with original fixed folds.
- `results/`: trained emission model, fitted scaler, HMM settings, fold scores, decoder search trials, candidate probabilities, per-observation and per-trip predictions, metrics.
- `src/`: training, feature extraction, reference decoder, compiled decoder, inference API.
- `test_inputs/`: 18-feature test candidates, observations and matching precomputed graph geometry for reproducing inference quickly.
- `PathSnap_HMM_Results.ipynb`: executed notebook showing measured results and reproducing inference from the saved models.
- `training.log`: complete captured training and tuning log.

## Use

Install `requirements.txt`, then open and run `PathSnap_HMM_Results.ipynb` from this folder. The bundled test inputs are already preprocessed. For new trips, derive candidates and the same 18 predictors with `src/pathsnap_features18.py`, provide the matching directed network, and call `predict()` in `src/predict.py`. Never reuse the bundled geometry cache for different observations or candidates.

For full retraining, put the original `PathSnap_shared6.zip` and `Student folder.zip` in `inputs/` under this folder and run `python src/run_training.py`. Rebuilding features and lattices takes longer than loading the trained model. The original raw network archive and training geometry caches are excluded from this ZIP; the derived 18-feature dataset is included. The original six-feature trained model is not used.

Candidate-level Macro F1 and log loss apply to XGBoost emissions. The sequence decoder does not produce calibrated candidate probabilities, so those metrics are left blank for its row.

Training and evaluation runtime, excluding dependency installation: 265.7 seconds.
