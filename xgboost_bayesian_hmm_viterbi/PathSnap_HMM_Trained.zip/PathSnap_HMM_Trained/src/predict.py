"""Inference for the trained PathSnap 18-feature XGBoost + HMM/Viterbi bundle."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import joblib
from xgboost import XGBClassifier
import pathsnap_xgb_hmm18 as core
from fast_decoder import decode_fast

def predict(candidates, observations, network_zip=None, split='student_test', model_dir=None, cache_dir=None):
    """Accept prepared candidates and GPS/network information without reference labels.

    Candidate arc IDs are trip-local. Geometry cache must match exactly the supplied
    candidate row order, observations and network. Use a new cache for new inputs.
    Returns one selected arc per observation; unmatched observations are -1.
    """
    model_dir=Path(model_dir or Path(__file__).resolve().parent.parent/'results')
    candidates=candidates.reset_index(drop=True).copy()
    observations=observations.copy()
    candidates['trip_id']=candidates.trip_id.astype(str)
    observations['trip_id']=observations.trip_id.astype(str)
    model=XGBClassifier();model.load_model(model_dir/'selected18_xgboost_model.ubj')
    scaler=joblib.load(model_dir/'selected18_scaler.joblib')
    config=json.loads((model_dir/'decoder_config.json').read_text())
    p=model.predict_proba(scaler.transform(candidates[core.FEATURES]))[:,1]
    ds=core.Dataset(candidates,observations)
    lattices=core.build_lattices(ds,network_zip,split,cache_dir or model_dir/'new_geometry_cache') if network_zip else []
    if network_zip is None:
        if cache_dir is None:raise ValueError('Supply network_zip or the exact matching precomputed cache_dir')
        for trip in sorted(observations.trip_id.unique()):
            with np.load(Path(cache_dir)/f'{split}_{trip}.npz',allow_pickle=False) as a:
                lattices.append({k:a[k].copy() for k in a.files})
    frames=[]
    for lattice in lattices:
        arcs,events=decode_fast(lattice,p,config)
        frames.append(pd.DataFrame({'observation_id':lattice['obs_ids'],'predicted_arc_id':arcs,'decoder_event':events}))
    decoded=pd.concat(frames,ignore_index=True)
    safe=[k for k in ['observation_id','trip_id','timestamp','longitude','latitude'] if k in observations]
    return observations[safe].merge(decoded,on='observation_id',validate='one_to_one')
