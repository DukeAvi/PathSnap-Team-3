from pathlib import Path
import time,json,sys,os,hashlib,shutil,importlib.metadata
import numpy as np,pandas as pd
import pathsnap_xgb_hmm18 as core
import pathsnap_features18 as features
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
START=time.perf_counter()
core.BASE_PARAMS.update(n_jobs=4,device='cpu')
print('Preparing unchanged trip splits and 18 label-free features',flush=True)
archive=features.prepare_shared18(core,ROOT/'inputs/PathSnap_shared6.zip',ROOT/'inputs/Student folder.zip',OUT)
train,test,folds,assignments,protocol=core.load_shared(archive)
assignments.to_csv(OUT/'fold_assignments.csv',index=False)
core.save_json(OUT/'shared_protocol.json',protocol)
pd.DataFrame([dict(split=n,trips=d.observations.trip_id.nunique(),observations=len(d.observations),candidates=len(d.candidates),candidate_coverage=float(d.observations.reference_present.mean())) for n,d in [('train',train),('student_test',test)]]).to_csv(OUT/'dataset_counts.csv',index=False)
print('Fitting five trip-disjoint emission models',flush=True)
best=dict(core.BASE_PARAMS)
oof,cv=core.cv_scores(train,folds,best,OUT/'cv_cache')
print(cv.to_string(index=False),flush=True)
cv.to_csv(OUT/'emission_cv_fold_metrics.csv',index=False)
np.save(OUT/'selected_oof_probabilities.npy',oof)
core.save_json(OUT/'selected_xgboost_parameters.json',best)
print('Building training directed transition lattices',flush=True)
t=time.perf_counter()
train_lattices=core.build_lattices(train,ROOT/'inputs/Student folder.zip','train',OUT/'geometry_cache')
train_geo=time.perf_counter()-t
# Compiled equivalent of the supplied recurrence, verified before tuning.
from fast_decoder import decode_fast
reference=core.decode_lattice
config0=dict(beta_m=50.,beta_displacement=.2,max_speed_mps=50.,slack_m=80.)
for lattice in train_lattices[:3]:
 a,r=reference(lattice,oof,config0); b,s=decode_fast(lattice,oof,config0)
 assert np.array_equal(a,b), 'Compiled Viterbi differs from original'
 assert np.array_equal(r,s), 'Compiled reset policy differs from original'
core.decode_lattice=decode_fast
print('Tuning HMM on all 80 training trips using out-of-fold emissions',flush=True)
# No XGBoost search: the user prioritised HMM training speed.
config,study=core.tune_decoder(train,train_lattices,oof,assignments,OUT,n_trials=80)
print('Selected training OOF decoder score',study.best_value,'config',config,flush=True)
# Freeze both stages before touching student-test labels.
core.save_json(OUT/'frozen_selection.json',{'emission_parameters':best,'decoder_parameters':config,'training_selection_objective':study.best_value,'decoder_trials':len(study.trials),'test_used_for_selection':False})
t=time.perf_counter()
model=core.XGBClassifier(**best); scaler=core.StandardScaler()
model.fit(scaler.fit_transform(train.candidates[core.FEATURES]),train.candidates.label)
fit_seconds=time.perf_counter()-t
model.save_model(OUT/'selected18_xgboost_model.ubj');core.joblib.dump(scaler,OUT/'selected18_scaler.joblib')
core.save_json(OUT/'selected18_model_config.json',{'features':core.FEATURES,'parameters':best,'preprocessing':'Apply selected18_scaler.joblib once before the emission model','final_fit_seconds':fit_seconds})
print('Frozen. Building held-out test lattices and evaluating once',flush=True)
t=time.perf_counter()
test_lattices=core.build_lattices(test,ROOT/'inputs/Student folder.zip','student_test',OUT/'geometry_cache')
test_geo=time.perf_counter()-t
comparison=core.export_comparison(train,test,folds,assignments,cv,cv,oof,oof,train_lattices,test_lattices,config,model,scaler,model,scaler,OUT)
comparison=comparison[comparison.Model!='Untuned XGBoost'].copy()
comparison['Model']=comparison.Model.replace({'Selected XGBoost':'XGBoost (18 features)','Selected XGBoost + HMM/Viterbi':'XGBoost (18 features) + HMM/Viterbi'})
# HMM Top-1 means one Viterbi-selected arc for every observation.
comparison.loc[comparison.Model.str.contains('HMM'),'Student-test Top-1']=comparison.loc[comparison.Model.str.contains('HMM'),'Pointwise Accuracy']
comparison.to_csv(OUT/'final_comparison.csv',index=False)
hmm=pd.read_csv(OUT/'hmm_student_observation_predictions.csv.gz')
hmm['correct']=hmm.predicted_arc_id==hmm.reference_arc_id
per=hmm.groupby('trip_id').agg(observations=('correct','size'),correct=('correct','sum'),top1_accuracy=('correct','mean'))
per.to_csv(OUT/'hmm_per_trip_metrics.csv')
metrics={'test_top1_accuracy':float(hmm.correct.mean()),'correct_observations':int(hmm.correct.sum()),'total_observations':len(hmm),'target_range':[.85,.95],'target_met':bool(.85<=hmm.correct.mean()<=.95),'test_candidate_coverage_upper_bound':float(test.observations.reference_present.mean()),'decoder_training_oof_selection_score':study.best_value,'final_emission_fit_seconds':fit_seconds,'training_geometry_seconds':train_geo,'test_geometry_seconds':test_geo,'total_runtime_seconds':time.perf_counter()-START,'labels':'Geometric weak reference labels, not independent ground truth','test_used_for_selection':False,'decoder_type':'Discriminative XGBoost emissions + directed-network HMM-style Viterbi; no Baum-Welch'}
core.save_json(OUT/'metrics.json',metrics)
print('FINAL METRICS',json.dumps(metrics),flush=True)
print(comparison.to_string(index=False),flush=True)
